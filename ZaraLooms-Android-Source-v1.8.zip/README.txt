Zara Looms - Android source (v1.8)

1. Android Studio එකේ "Open" කරලා මේ folder එක open කරන්න.
2. app/build.gradle එකේ signingConfigs.release විස්තර බලන්න (key file: zara_looms_key.p12,
   password: android, alias: androiddebugkey). Key file එක project root එකේ තියෙනවා.
3. Build > Generate Signed App Bundle / APK > APK තෝරලා build කරන්න.
4. Phone එකේ පරණ v1.7 app එකට උඩින්ම install වෙනවා (uninstall කරන්න එපා).

Native (Java) කොටස් - MainActivity, ReminderScheduler, ReminderReceiver, BootReceiver:
  - PDF WhatsApp / share  -> AndroidBridge.sharePdf / savePdf
  - උදේ 7ට notification  -> AndroidBridge.setReminders / reminderOn / setReminderOn / testNotify
Web page (assets/index.html) එක වෙනම update කරන්න ඕන නම් assets folder එකේ විතරක් වෙනස් කරන්න.
