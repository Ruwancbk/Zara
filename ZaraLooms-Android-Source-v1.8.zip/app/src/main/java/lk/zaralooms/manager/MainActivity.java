package lk.zaralooms.manager;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;
import android.app.Activity;
import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private ActivityResultLauncher<Intent> fileLauncher;

    static final String SHIM =
        "(function(){var C=window.Capacitor=window.Capacitor||{};var P=C.Plugins=C.Plugins||{};var d='';"
        + "P.Filesystem={writeFile:function(o){d=o.data;return Promise.resolve({uri:'file://'+o.path});}};"
        + "P.Share={share:function(o){AndroidBridge.share(o.title||'Backup',d);return Promise.resolve();}};})();";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (fileCb == null) return;
            Uri[] res = null;
            if (r.getResultCode() == Activity.RESULT_OK && r.getData() != null) {
                res = new Uri[]{ r.getData().getData() };
            }
            fileCb.onReceiveValue(res);
            fileCb = null;
        });

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(SHIM, null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                fileLauncher.launch(Intent.createChooser(i, "ෆයිල් තෝරන්න"));
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    /** Methods called from JavaScript as AndroidBridge.xxx(...) */
    class Bridge {

        @android.webkit.JavascriptInterface
        public void share(String title, String text) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, title));
        }

        /** Writes base64 PDF into cache and opens the share sheet (WhatsApp is in it). */
        @android.webkit.JavascriptInterface
        public String sharePdf(String b64, String name) {
            try {
                File dir = new File(getCacheDir(), "shared");
                dir.mkdirs();
                File f = new File(dir, safe(name));
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(Base64.decode(b64, Base64.DEFAULT));
                }
                Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "PDF share කරන්න"));
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        /** Saves base64 PDF into Downloads/Zara Looms (Android 10+). */
        @android.webkit.JavascriptInterface
        public String savePdf(String b64, String name) {
            if (Build.VERSION.SDK_INT < 29) return "error: Android 10 ට උඩ අවශ්‍යයි";
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, safe(name));
                cv.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Zara Looms");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(Base64.decode(b64, Base64.DEFAULT));
                }
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        @android.webkit.JavascriptInterface
        public void setReminders(String json) {
            ReminderScheduler.save(MainActivity.this, json);
        }

        @android.webkit.JavascriptInterface
        public String reminderOn() {
            return ReminderScheduler.isOn(MainActivity.this) ? "1" : "0";
        }

        @android.webkit.JavascriptInterface
        public void setReminderOn(boolean on) {
            ReminderScheduler.setOn(MainActivity.this, on);
        }

        @android.webkit.JavascriptInterface
        public String testNotify() {
            return ReminderScheduler.testNotify(MainActivity.this);
        }
    }

    static String safe(String n) {
        return n.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}
