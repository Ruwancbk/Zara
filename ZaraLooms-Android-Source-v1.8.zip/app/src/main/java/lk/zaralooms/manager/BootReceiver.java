package lk.zaralooms.manager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarms are lost on reboot, so set them again from the saved schedule. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction()) && ReminderScheduler.isOn(c)) {
            ReminderScheduler.schedule(c, ReminderScheduler.prefs(c).getString("json", "{}"));
        }
    }
}
