package lk.zaralooms.manager;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.Calendar;
import java.util.Iterator;
import org.json.JSONObject;

/** Stores the reminder schedule from the web page and sets one alarm per date at 07:00. */
public class ReminderScheduler {

    static final String PREFS = "zl_remind";
    static final String CH = "daily_reminders";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isOn(Context c) {
        return prefs(c).getBoolean("on", true);
    }

    static void setOn(Context c, boolean on) {
        prefs(c).edit().putBoolean("on", on).apply();
        String json = prefs(c).getString("json", "{}");
        if (on) schedule(c, json); else cancel(c, json);
    }

    /** Called from JavaScript with {"2026-10-28": {"t":"...","b":"..."}, ...} */
    static void save(Context c, String json) {
        String old = prefs(c).getString("json", "{}");
        cancel(c, old);
        prefs(c).edit().putString("json", json).apply();
        if (isOn(c)) schedule(c, json);
    }

    static int requestCode(String date) {
        return Integer.parseInt(date.replace("-", ""));
    }

    static PendingIntent pending(Context c, String date, int flags) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("date", date);
        return PendingIntent.getBroadcast(c, requestCode(date), i, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    static void schedule(Context c, String json) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            JSONObject o = new JSONObject(json);
            long now = System.currentTimeMillis();
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String date = keys.next();
                String[] p = date.split("-");
                Calendar cal = Calendar.getInstance();
                cal.clear();
                cal.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]), 7, 0, 0);
                long at = cal.getTimeInMillis();
                if (at <= now) continue; // past 7am already
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at,
                        pending(c, date, PendingIntent.FLAG_UPDATE_CURRENT));
            }
        } catch (Exception e) {
            // bad json: nothing to schedule
        }
    }

    static void cancel(Context c, String json) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            JSONObject o = new JSONObject(json);
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String date = keys.next();
                PendingIntent pi = pending(c, date, PendingIntent.FLAG_NO_CREATE);
                if (pi != null) { am.cancel(pi); pi.cancel(); }
            }
        } catch (Exception e) {
            // ignore
        }
    }

    /** Builds and shows the notification for one date. */
    static void show(Context c, String date) {
        try {
            JSONObject o = new JSONObject(prefs(c).getString("json", "{}"));
            JSONObject e = o.optJSONObject(date);
            if (e == null) return;
            postNotification(c, e.optString("t", "Zara Looms"), e.optString("b", ""), requestCode(date));
        } catch (Exception ex) {
            // ignore
        }
    }

    static String testNotify(Context c) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return "error: notification permission දෙන්න";
        }
        postNotification(c, "Zara Looms • test", "Notification වැඩ කරනවා ✅", 1);
        return "ok";
    }

    static void postNotification(Context c, String title, String text, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "දෛනික මතක් කිරීම්",
                    NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(R.mipmap.ic_launcher)
         .setContentTitle(title)
         .setContentText(text.split("\n")[0])
         .setStyle(new Notification.BigTextStyle().bigText(text))
         .setAutoCancel(true)
         .setContentIntent(pi);
        nm.notify(id, b.build());
    }
}
