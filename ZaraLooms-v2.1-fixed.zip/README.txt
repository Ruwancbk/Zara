Zara Looms v2.1 (versionCode 112)

APK හදන හැටි (GitHub Actions):
1. මේ ZIP එකේ ඇති සියලු ගොනු (.github folder එකත් සමඟ) ඔබේ repository එකට upload කරන්න (පරණ ගොනු උඩින් replace).
2. පරණ app එක (v1.6 / v1.7 / v2.0) උඩින් update වී දත්ත ඉතුරු වීමට නම්, ඒවාට භාවිතා කළ
   zara_looms_key.p12 ගොනුව repository root එකේ තිබිය යුතුයි (දැනටමත් තිබේ නම් ඒ ලෙසම තබන්න).
   Key එක නැතිනම් build එක debug key එකෙන් sign වේ - එවිට පරණ app එක uninstall කරන්න වේ
   (uninstall කළොත් දත්ත මැකේ, කලින් Backup ගන්න!).
3. Actions tab -> "Build APK" -> run වූ පසු Artifacts වලින් ZaraLooms-v2.1-apk බාගන්න.
   (ඔබේ repo එකේ දැනටමත් වෙනත් workflow එකක් තිබේ නම්, build-apk.yml එක අවශ්‍ය නැත - ඒ workflow එකම භාවිතා කරන්න.)

Page එක https://localhost/index.html මගින් load වෙනවා (පරණ දත්ත එකම තැනයි).
