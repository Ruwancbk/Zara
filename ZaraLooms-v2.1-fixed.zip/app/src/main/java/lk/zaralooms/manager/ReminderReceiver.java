package lk.zaralooms.manager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fired by AlarmManager at 07:00 on the due date. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        if (!ReminderScheduler.isOn(c)) return;
        String date = intent.getStringExtra("date");
        if (date != null) ReminderScheduler.show(c, date);
    }
}
