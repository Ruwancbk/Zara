package lk.zaralooms.manager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Reboot / app update / වේලාව හෝ timezone වෙනස් වූ විට alarms නැවත සකසයි. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String a = intent.getAction();
        if (a == null || !ReminderScheduler.isOn(c)) return;
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)) {
            ReminderScheduler.schedule(c, ReminderScheduler.prefs(c).getString("json", "{}"));
            if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
                ReminderScheduler.catchUp(c);
            }
        }
    }
}
