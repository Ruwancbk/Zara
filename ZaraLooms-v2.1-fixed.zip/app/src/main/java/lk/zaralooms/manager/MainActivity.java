package lk.zaralooms.manager;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;
import android.app.Activity;
import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private ActivityResultLauncher<Intent> fileLauncher;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (fileCb == null) return;
            Uri[] res = null;
            if (r.getResultCode() == Activity.RESULT_OK && r.getData() != null) {
                res = new Uri[]{ r.getData().getData() };
            }
            fileCb.onReceiveValue(res);
            fileCb = null;
        });

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            /** App එකෙන් පිටතට navigate වීම වළක්වයි (JS bridge ආරක්ෂාව). tel: සඳහා dialer එක විවෘත කරයි. */
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u == null) return true;
                if ("https".equals(u.getScheme()) && "localhost".equals(u.getHost())) return false;
                if ("tel".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_DIAL, u)); } catch (Exception e) { /* ignore */ }
                }
                return true;
            }

            /** Serves assets as https://localhost/... so old data (same origin as v1.6/v1.7) is kept. */
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u != null && "https".equals(u.getScheme()) && "localhost".equals(u.getHost())) {
                    String p = u.getPath();
                    if (p == null || p.isEmpty() || "/".equals(p)) p = "/index.html";
                    p = p.substring(1);
                    try {
                        InputStream in = getAssets().open(p);
                        return new WebResourceResponse(mimeOf(p), "utf-8", in);
                    } catch (IOException e) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                }
                // localhost නොවන සියලු request අවහිර කරයි
                return new WebResourceResponse("text/plain", "utf-8", 403, "Forbidden",
                        new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                fileLauncher.launch(Intent.createChooser(i, "ෆයිල් තෝරන්න"));
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        setupBack();
        web.loadUrl("https://localhost/index.html");
    }

    /** Back: popup එක වසන්න → මුල් පිටුවට යන්න → අන්තිමට app එකෙන් ඉවත් වෙන්න. */
    private void setupBack() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript(
                    "(function(){try{var m=document.getElementById('modal');"
                    + "if(m&&m.classList.contains('show')){closeM();return 1}"
                    + "if(typeof tab!=='undefined'&&tab!=='home'){go('home');return 1}}catch(e){}return 0})()",
                    value -> { if (!"1".equals(value)) finish(); });
            }
        });
    }

    /** Methods called from JavaScript as AndroidBridge.xxx(...) */
    class Bridge {

        @android.webkit.JavascriptInterface
        public void share(String title, String text) {
            if (text != null && text.length() > 60000) { shareFile(text, "zara-looms.txt", "text/plain"); return; }
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, title));
        }

        /** Plain text (JSON backup) ගොනුවක් ලෙස cache එකට ලියා share sheet එක විවෘත කරයි. */
        @android.webkit.JavascriptInterface
        public String shareFile(String text, String name, String mime) {
            try {
                cleanCache();
                File dir = new File(getCacheDir(), "shared");
                dir.mkdirs();
                File f = new File(dir, safe(name));
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(text.getBytes("UTF-8"));
                }
                Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.setClipData(android.content.ClipData.newRawUri(name, u));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Backup එක සුරකින්න / යවන්න"));
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        /** Plain text ගොනුවක් Downloads/Zara Looms ට save කරයි (Android 10+). */
        @android.webkit.JavascriptInterface
        public String saveFile(String text, String name, String mime) {
            if (Build.VERSION.SDK_INT < 29) return "error: Android 10 ට උඩ අවශ්‍යයි (Share බොත්තම භාවිතා කරන්න)";
            try {
                return writeDownload(text.getBytes("UTF-8"), safe(name), mime);
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        /** Writes base64 PDF into cache and opens the share sheet (WhatsApp is in it). */
        @android.webkit.JavascriptInterface
        public String sharePdf(String b64, String name) {
            try {
                cleanCache();
                File dir = new File(getCacheDir(), "shared");
                dir.mkdirs();
                File f = new File(dir, safe(name));
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(Base64.decode(b64, Base64.DEFAULT));
                }
                Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.setClipData(android.content.ClipData.newRawUri(name, u));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "PDF share කරන්න"));
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        /** Saves base64 PDF into Downloads/Zara Looms (Android 10+). */
        @android.webkit.JavascriptInterface
        public String savePdf(String b64, String name) {
            if (Build.VERSION.SDK_INT < 29) return "error: Android 10 ට උඩ අවශ්‍යයි";
            try {
                return writeDownload(Base64.decode(b64, Base64.DEFAULT), safe(name), "application/pdf");
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        @android.webkit.JavascriptInterface
        public void setReminders(String json) {
            ReminderScheduler.save(MainActivity.this, json);
        }

        @android.webkit.JavascriptInterface
        public String reminderOn() {
            return ReminderScheduler.isOn(MainActivity.this) ? "1" : "0";
        }

        @android.webkit.JavascriptInterface
        public void setReminderOn(boolean on) {
            ReminderScheduler.setOn(MainActivity.this, on);
        }

        @android.webkit.JavascriptInterface
        public String testNotify() {
            return ReminderScheduler.testNotify(MainActivity.this);
        }
    }

    /** Downloads/Zara Looms ට ලියයි. අසාර්ථක නම් අඩකට ලියූ ගොනුව ඉවත් කරයි. */
    String writeDownload(byte[] data, String name, String mime) throws IOException {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
        cv.put(MediaStore.Downloads.MIME_TYPE, mime);
        cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Zara Looms");
        cv.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        if (u == null) throw new IOException("Downloads folder එකට ලියන්න බැරි වුණා");
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            if (o == null) throw new IOException("ගොනුව විවෘත කරන්න බැරි වුණා");
            o.write(data);
        } catch (IOException e) {
            getContentResolver().delete(u, null, null);
            throw e;
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.Downloads.IS_PENDING, 0);
        getContentResolver().update(u, done, null, null);
        return "ok";
    }

    /** cache/shared හි පැය 24කට වඩා පරණ ගොනු මකයි. */
    void cleanCache() {
        try {
            File[] fs = new File(getCacheDir(), "shared").listFiles();
            if (fs == null) return;
            long old = System.currentTimeMillis() - 24L * 3600 * 1000;
            for (File f : fs) if (f.lastModified() < old) f.delete();
        } catch (Exception e) { /* ignore */ }
    }

    static String mimeOf(String p) {
        String l = p.toLowerCase();
        if (l.endsWith(".html") || l.endsWith(".htm")) return "text/html";
        if (l.endsWith(".js")) return "application/javascript";
        if (l.endsWith(".css")) return "text/css";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".webp")) return "image/webp";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".svg")) return "image/svg+xml";
        if (l.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    static String safe(String n) {
        return n.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}
